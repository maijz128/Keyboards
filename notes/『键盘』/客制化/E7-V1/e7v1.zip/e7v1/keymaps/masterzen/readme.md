# masterzen's Keymap

![masterzen keymap Layout Image](https://imgur.com/SF4UP2j)

Keymap Maintainer: [masterzen](https://github.com/masterzen)


Difference from base layout: 
 * split backspace
 * Home & End on last keys of row 0 instead of Insert/Del
 * Fn is on the End key when hold
 * supports both a windows/linux keymap and osx keymap
 * layer change is reflected in the rgb leds of the logo

