# ANSI split backspace Keymap

Split backspace ANSI keymap with a base layer and an adjust layer.

Keymap Maintainer: [masterzen](https://github.com/amnesia0287)
