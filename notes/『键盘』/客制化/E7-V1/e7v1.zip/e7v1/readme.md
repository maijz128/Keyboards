# E7-V1

![E7-V1](https://imgur.com/a/5v5pV9U)

A 75% keyboard made by Exclusive and run in a Geekhack group buy.

Keyboard Maintainer: [masterzen](https://github.com/masterzen)  
Hardware Supported: E7 - V1 QMK PCB LED  
Hardware Availability: [https://geekhack.org/index.php?topic=97182.msg2654226#msg2654226](https://geekhack.org/index.php?topic=97182.msg2654226#msg2654226)

Make example for this keyboard (after setting up your build environment):

    make exclusive/e7v1:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
